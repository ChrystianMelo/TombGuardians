using UnityEditor;

namespace Unity.InteractiveTutorials.Tests
{
    public class TestWindow2 : EditorWindow
    {
    }
}
