﻿using UnityEngine;

namespace Unity.InteractiveTutorials.Tests
{
    class TestAsset : ScriptableObject { }
}