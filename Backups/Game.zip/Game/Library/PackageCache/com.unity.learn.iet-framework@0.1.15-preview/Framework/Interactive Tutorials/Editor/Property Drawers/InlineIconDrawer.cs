using UnityEditor;

namespace Unity.InteractiveTutorials
{
    [CustomPropertyDrawer(typeof(InlineIcon))]
    class InlineIconDrawer : FlushChildrenDrawer
    {
    }
}
