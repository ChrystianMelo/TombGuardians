namespace Unity.InteractiveTutorials
{
    public interface IPlayerAvatar {}
}
